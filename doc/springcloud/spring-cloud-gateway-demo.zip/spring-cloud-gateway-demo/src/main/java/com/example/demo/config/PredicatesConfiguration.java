package com.example.demo.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author machenggong
 * @since 2023/2/23
 */
@Configuration
public class PredicatesConfiguration {

//    public CustomRoutePredicateFactory customRoutePredicateFactory(){
//        return new CustomRoutePredicateFactory();
//    }

}
