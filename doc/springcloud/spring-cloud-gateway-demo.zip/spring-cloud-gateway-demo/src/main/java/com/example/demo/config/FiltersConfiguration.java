package com.example.demo.config;

import com.example.demo.filters.NameValueGatewayFilterFactory;
import com.example.demo.filters.NoParamGatewayFilterFactory;
import com.example.demo.filters.ParamCheckGatewayFilterFactory;
import org.springframework.cloud.gateway.config.conditional.ConditionalOnEnabledFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author machenggong
 * @since 2023/2/23
 */
@Configuration
public class FiltersConfiguration {

    @Bean
    //@ConditionalOnEnabledFilter
    public NameValueGatewayFilterFactory nameValueGatewayFilterFactory() {
        return new NameValueGatewayFilterFactory();
    }


    @Bean
    @ConditionalOnEnabledFilter
    public ParamCheckGatewayFilterFactory paramCheckGatewayFilterFactory() {
        return new ParamCheckGatewayFilterFactory();
    }

    @Bean
    @ConditionalOnEnabledFilter
    public NoParamGatewayFilterFactory noParamGatewayFilterFactory() {
        return new NoParamGatewayFilterFactory();
    }

}
