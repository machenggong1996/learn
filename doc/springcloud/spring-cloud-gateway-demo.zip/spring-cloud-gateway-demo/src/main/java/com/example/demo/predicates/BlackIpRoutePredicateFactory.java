package com.example.demo.predicates;

import com.example.demo.utils.IpUtil;
import org.springframework.cloud.gateway.handler.predicate.AbstractRoutePredicateFactory;
import org.springframework.cloud.gateway.handler.predicate.GatewayPredicate;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/**
 * @author machenggong
 * @since 2023/2/23
 */
@Component
public class BlackIpRoutePredicateFactory extends AbstractRoutePredicateFactory<BlackIpRoutePredicateFactory.Config> {
    public BlackIpRoutePredicateFactory() {
        super(BlackIpRoutePredicateFactory.Config.class);
    }

    //根据这个配置来进行转换
    @Override
    public ShortcutType shortcutType() {
        return ShortcutType.GATHER_LIST;
    }

    //制定属性
    @Override
    public List<String> shortcutFieldOrder() {
        return Collections.singletonList("ips");
    }

    @Override
    public Predicate<ServerWebExchange> apply(Config config) {

        return new GatewayPredicate() {
            @Override
            public boolean test(ServerWebExchange exchange) {
                String ip = IpUtil.getIp(exchange.getRequest());
                List<String> ips = config.getIps();
                return ips.contains(ip);
            }
        };
    }

    public static class Config {

        private List<String> ips;

        public List<String> getIps() {
            return ips;
        }

        public void setIps(List<String> ips) {
            this.ips = ips;
        }
    }
}
